if (window.location.href.indexOf('https://coinmarketcap.com/') === 0) {
    coinmarketcapHandler()
}

if (window.location.href.indexOf('https://www.coingecko.com/') === 0) {
    coingeckoHandler()
}
